package iesmm.pmdm.simonapp;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private Button buttons[]; // Botones
    private int colors[]; // Colores asociados

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Definición estática de botones y colores
        buttons = new Button[4];
        buttons[0] = this.findViewById(R.id.b1);
        buttons[1] = this.findViewById(R.id.b2);
        buttons[2] = this.findViewById(R.id.b3);
        buttons[3] = this.findViewById(R.id.b4);

        // Colores iniciales
        /*
        buttons[0].setBackgroundColor(Color.GREEN);
        buttons[1].setBackgroundColor(Color.RED);
        buttons[2].setBackgroundColor(Color.YELLOW);
        buttons[3].setBackgroundColor(Color.BLUE);
        */

        colors = new int[4];
        colors[0] = Color.GREEN;
        colors[1] = Color.RED;
        colors[2] = Color.YELLOW;
        colors[3] = Color.BLUE;

        // Inicio de tarea asíncrona
        new MyTask().execute();
    }

    private class MyTask extends AsyncTask<Void, Integer, Void> {
        private final String TAG = "PMDM";
        private final int DELAY = 3 * 1000; // 5 seconds
        private final int NVECES = 6; // 6 selecciones de color en nivel por defecto

        /*
        onPreExecute:
        Método llamado antes de empezar el procesamiento en segundo plano de doInBackground.
         */
        @Override
        protected void onPreExecute() {
            // Color por defecto
            for (Button b : buttons)
                b.setBackgroundColor(Color.BLACK);
        }

        /*
        doInBackground:
        este método se ejecuta en un thread separado, lo que le permite ejecutar un tratamiento pesado en una tarea de segundo plano.
        Recibe como parámetros los declarados al llamar al método execute(Params).
         */
        @Override
        protected Void doInBackground(Void... params) {
            int n = 0;
            int pos; // button random

            while (n < NVECES) {
                try {
                    // 1. Actualización en vista
                    pos = (int) (Math.random() * buttons.length);
                    publishProgress(pos); // Llamada interna a onProgressUpdate()

                    // 2. Delay
                    Thread.sleep(DELAY);

                    // 3. Restablecer color por defecto en button "pos"
                    publishProgress(-1, pos);

                    n++;

                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

            // Finalización del proceso
            return null; // Al hacer return llama a: onPostExecute()
        }

        /*
        onProgressUpdate:
        es llamado por publishProgress(), dentro de doInBackground(Params) (su uso es muy común para por ejemplo actualizar el porcentaje de un componente ProgressBar).
         */
        @Override
        protected void onProgressUpdate(Integer... values) {
            if (values[0] >= 0) {
                // Actualización en UI
                Log.d(TAG, "Botón actualizado: " + values[0]);
                buttons[values[0]].setBackgroundColor(colors[values[0]]);
                Toast.makeText(getApplicationContext(),"Botón " + values[0], Toast.LENGTH_LONG).show();
            } else
                // Valor por defecto
                buttons[values[1]].setBackgroundColor(Color.BLACK);
        }

        /*
        Este método es llamado tras finalizar doInBackground(Params).
        Recibe como parámetro el resultado devuelto por doInBackground(Params).
         */
        @Override
        protected void onPostExecute(Void param) {
            Log.d(TAG, "TAREA ASÍNCRONA FINALIZADA");
            Toast.makeText(getApplicationContext(),"FIN DE JUEGO", Toast.LENGTH_LONG).show();
        }
    }
}