package iesmm.pmdm.pmdm_t3_listview;

import android.content.DialogInterface;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {
    private ArrayAdapter adaptador;
    private final ArrayList listaDNI = new ArrayList();

    Date date = new Date();
    DateFormat fecha = new SimpleDateFormat("dd-MM-yyyy");
    private final String FILENAME = "cliente-" + fecha.format(date) + "lista.txt";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        loadData();
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public void putItem(View view) {
        //1.Localizar el editText del layout.
        EditText texto = this.findViewById(R.id.editText);

        //Declaración de pattern utilizado para validar
        Pattern patron = Pattern.compile("[0-9]{8}[A-Z a-z]");
        Matcher mat = patron.matcher(texto.getText().toString());


        //2. Obtener el texto y meterlo en el adaptador de datos
        if (!texto.getText().toString().isEmpty()) {
            if (mat.matches()) {
                if (!listaDNI.contains(texto.getText().toString())) {

                    adaptador.add(texto.getText().toString());
                    adaptador.sort(Comparator.naturalOrder());

                } else {
                    Toast.makeText(this, "EL DNI ya existe", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "El dni es incorrecto", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "EL campo está vacío", Toast.LENGTH_SHORT).show();
        }
    }

    //Método para eliminar dni
    private void eliminaDni(EditText dni) {
        if (listaDNI.contains(dni.getText().toString())) {
            adaptador.remove(dni.getText().toString());
            Toast.makeText(this, "DNI eliminado", Toast.LENGTH_SHORT).show();
        } else if (dni.getText().toString().isEmpty()) {
            Toast.makeText(this, "campo vacío", Toast.LENGTH_SHORT).show();
        }
    }


    public void clearItems(View view) {
        //1. volcar el contenido del listview a un almacenamiento externo
        escribirFichero();

        //2. Vaciar el listview
        if (!adaptador.equals(null)) {
            adaptador.clear();
        } else {
            throw new NullPointerException("Valores nulos");
        }
    }

    private void escribirFichero() {
        //1.Obtener la ruta del directorio del montaje de la memoria externa
        File dir = this.getExternalFilesDir(null);
        if (dir.canWrite()) {
            File file = new File(dir, FILENAME);
            Toast.makeText(this, file.getAbsolutePath(), Toast.LENGTH_SHORT).show();
            try {
                FileWriter fout = new FileWriter(file);
                for (int i = 0; i < adaptador.getCount(); i++) {
                    fout.write(adaptador.getItem(i).toString() + "\n");
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
        } else
            Toast.makeText(this, "error E/S", Toast.LENGTH_SHORT).show();
    }

    public void loadData() {
        //cargar esos datos en un listview
        AddItemsInListView(listaDNI);
    }

    private void AddItemsInListView(ArrayList lista) {
        //Localizar el listView dentro del layout
        ListView listaVista = this.findViewById(R.id.listView1);

        //Creamos adaptador de datos y vincular los datos en el listView
        adaptador = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_list_item_1, lista);
        listaVista.setAdapter(adaptador);

        listaVista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int i, long id) {
                String txt = "Nº posición " + i + "\n Nº de elementos de la lista" + adaptador.getCount();
                txt += "\n valor del elemento: " + adaptador.getItem(i);
                Toast.makeText(getApplicationContext(), txt, Toast.LENGTH_SHORT).show();

                //cuadro de dialogo
                Dialogo(i);

            }//método creado

            private void Dialogo(int i) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle(R.string.titulo);
                builder.setMessage(R.string.messborrarDNi);
                builder.setPositiveButton(R.string.accept, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        listaDNI.remove(i);
                        adaptador.notifyDataSetChanged();
                    }
                }).setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        cancelar();
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
    }

    private void mensajeAlerta() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.titErrorDni);
        builder.setMessage(R.string.messErrorDni);
        builder.setPositiveButton(R.string.accept, null);
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    public void cancelar() {
        Toast.makeText(this, "Operación cacelada", Toast.LENGTH_SHORT).show();

    }


}