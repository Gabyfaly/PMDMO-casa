package iesmm.pmdm.pmdm_t3_gestoracceso;

import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class MainActivity extends AppCompatActivity {
    private final String LOGTAG = "pmdm";
    private final String FILENAME = "accesos.dat";

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        registrarEntrada("ENTRADA", LocalDateTime.now());
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onDestroy() {
        super.onDestroy();
        registrarSalida("SAlIDA", LocalDateTime.now());

    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onPause() {
        super.onPause();
        registrarSalida("SALIDA", LocalDateTime.now());
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onResume() {
        super.onResume();
        registrarEntrada("ENTRADA", LocalDateTime.now());
    }

    //Método para registrar la entrada
    @RequiresApi(api = Build.VERSION_CODES.O)
    private void registrarEntrada(String entrada, LocalDateTime fecha) {
        Log.i(LOGTAG, "Entrada");
        try {
            //1. Recuperar flujo de escritura
            DataOutputStream fout = new DataOutputStream(this.openFileOutput(FILENAME, Context.MODE_APPEND));

            //2. Añadir al fichero
            fout.writeUTF(entrada + ";");
            fout.writeUTF(fecha.now().format(DateTimeFormatter.ISO_LOCAL_DATE) + ";");
            fout.writeUTF(fecha.now().format(DateTimeFormatter.ISO_LOCAL_TIME) + "; ");

            fout.close();
        } catch (FileNotFoundException e) {
            Log.e(LOGTAG, "Fichero no encontrado");
        } catch (IOException io) {
            Log.e(LOGTAG, "error E/S");

        } catch (Exception ex) {
            Log.e(LOGTAG, "Error General");

        }

    }

    //Método para registrar la salida
    @RequiresApi(api = Build.VERSION_CODES.O)
    private void registrarSalida(String salida, LocalDateTime fecha) {
        Log.i(LOGTAG, "salida");
        try {
            //1. Recuperar flujo de escritura
            DataOutputStream fout = new DataOutputStream(this.openFileOutput(FILENAME, Context.MODE_APPEND));

            //2. Añadir al fichero
            fout.writeUTF(salida + ";");
            fout.writeUTF(fecha.now().format(DateTimeFormatter.ISO_LOCAL_DATE) + ";");
            fout.writeUTF(fecha.now().format(DateTimeFormatter.ISO_LOCAL_TIME) + "; ");

            fout.close();
        } catch (FileNotFoundException e) {
            Log.e(LOGTAG, "Fichero no encontrado");
        } catch (IOException io) {
            Log.e(LOGTAG, "error E/S");

        } catch (Exception ex) {
            Log.e(LOGTAG, "Error General");

        }

    }

    private void leerEstado(String entrada) {

    }

    private void mostrarBox() {
        //1. identificar el contenedor del layoutt
        LinearLayout layout = this.findViewById(R.id.container);
        TableLayout tl = new TableLayout(this);
        tl.setGravity(Gravity.CENTER);
        TableRow tr = new TableRow(this);


        //2. Personalizar el objeto TextView
        TextView entrada = new TextView(this);
        //entradas
        entrada.setText("entrada");
        TextView fecha = new TextView(this);
        fecha.setText("Fecha");
        TextView hora = new TextView(this);
        hora.setText("hora");


        //3. Agregar el textView al container
        //layout.addView(box);
    }
}