package iesmm.pmdm.pmdm_t3_configapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
private static int contadorModificacion = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true; /** true -> el menú ya está visible */
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.save_settings:
                almacenarConfiguracion();
                break;
            case R.id.load_settings:
                recuperarConfiguracion();
                break;
            case R.id.reset_settings:
                restablecerConfiguracion();
            default:
                Toast.makeText(this, item.getTitle().toString(), Toast.LENGTH_SHORT).show();
        }
        return super.onOptionsItemSelected(item);
    }

    private void almacenarConfiguracion(){
        EditText campoEmail = findViewById(R.id.campo_email);
        EditText campoPassword = findViewById(R.id.campo_password);
        String email= campoEmail.getText().toString();
        String password=campoPassword.getText().toString();
        //1.Recuperar el objeto de la preferencias
        SharedPreferences pref = this.getSharedPreferences("misPreferencias", Context.MODE_PRIVATE);

        //2.Editar preferencias compartidas
        SharedPreferences.Editor editor = pref.edit();

        //3. Almacenar clave valor
        if (!email.equals(null) || !password.equals(null)){
            editor.putString("Email",(email));
            editor.putString("Password",(password));
            //4. Confirmar los cambios
            editor.commit();
            contadorModificacion++;
            mensajeAlmacenarConfiguracion();
        }else{
            //poner alertDialog si se introduce algun campo vacio.
            mensajeAlerta();
        }
    }

    private void recuperarConfiguracion(){

        //1. Recuperar el objeto de las preferencias
        SharedPreferences pref = this.getSharedPreferences("misPreferencias", Context.MODE_PRIVATE);

        //2. Recuperar valor
        String email = pref.getString("Email",null);
        String password = pref.getString("Password",null);
        //Comprobar que el color de fondo sea distinto a null
        if (email !=null && password !=null){
            EditText campoEmail = findViewById(R.id.campo_email);
            campoEmail.setText(email);
            EditText campoPassword = findViewById(R.id.campo_password);
            campoPassword.setText(password);
        }else{
            mensajeRecuperarConfiguracion();
        }
    }

    private void restablecerConfiguracion() {

        EditText campoEmail = findViewById(R.id.campo_email);
        EditText campoPassword = findViewById(R.id.campo_password);
        String email= campoEmail.getText().toString();
        String password=campoPassword.getText().toString();

        if (email != null || password != null){
            campoEmail.setText(null);
            campoPassword.setText(null);

        }else{
            mensajeRestablecer();
        }
    }

    private void mensajeAlerta(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.title_alerta);
        builder.setMessage(R.string.mesage_alerta);
        builder.setPositiveButton(R.string.aceptar, null);
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void mensajeAlmacenarConfiguracion(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.title_almacenar);
        builder.setMessage(R.string.mesage_almacenar);
        builder.setMessage("El número de modificaciones es: " + contadorModificacion);
        builder.setPositiveButton(R.string.aceptar, null);
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void mensajeRestablecer(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.title_restablecer);
        builder.setMessage(R.string.mesage_restablecer);
        builder.setPositiveButton(R.string.aceptar, null);

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void mensajeRecuperarConfiguracion(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.title_recuperar);
        builder.setMessage(R.string.mesage_recuperar);
        builder.setPositiveButton(R.string.aceptar, null);

        AlertDialog dialog = builder.create();
        dialog.show();
    }
}